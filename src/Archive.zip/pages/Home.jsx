
export default function Home() {
  return (
    <>
      <h1>Home Page</h1>
      <p>If you see this, routing is fixed.</p>
    </>
  );
}
